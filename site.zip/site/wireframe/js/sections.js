// Section kit. Every renderer returns an html`` fragment (Raw). Copy always arrives from docs.json.
import { html, raw, txt, icon } from './dom.js';
import { href } from './router.js';
import { LOGO, photo, stock, techTile, splitTech, TOPICS, CERTS, CLIENTS, TESTIMONIAL } from './assets.js';

const CPG_VERIFY = 'https://enquiries.cpg.global/web/enquiry.nsf/enquiry.xsp?Open&id=ISMS/20/R84/1419';
export const CONTACT = { phone: '+61 414 734 277', phoneHref: 'tel:+61414734277', email: 'enquiry@ptnglobalcorp.com' };

export const CATEGORY_ICON = {
  'Core Application Development': 'code',
  'Emerging Technologies': 'brain',
  'Cloud & DevOps': 'cloud',
  'Testing & Quality Assurance': 'bug-beetle',
  'Design, Support & Maintenance': 'pen-nib',
};

/* ---------- headings ---------- */

/** Title with its accented clause. `accent` must be a substring of `title`. */
export function splitTitle(title, accent) {
  const t = txt(title);
  if (!accent || !t.includes(accent)) return html`${t}`;
  const i = t.lastIndexOf(accent);
  return html`${t.slice(0, i)}<span class="accent">${accent}</span>${t.slice(i + accent.length)}`;
}

export const eyebrow = (label) => (label ? html`<p class="eyebrow"><span aria-hidden="true">// </span>${label}</p>` : '');

export function head({ eyebrow: eb, title, accent, lead, actions, level = 2, align = 'start', id }) {
  const H = level === 1 ? 'h1' : 'h2';
  return html`<header class="s-head s-head--${align}">
    ${eyebrow(eb)}
    ${raw(`<${H} class="display display--${level}"${id ? ` id="${id}"` : ''}>`)}${splitTitle(title, accent)}${raw(`</${H}>`)}
    ${lead ? html`<p class="lead">${txt(lead)}</p>` : ''}
    ${actions ? html`<div class="s-actions">${actions}</div>` : ''}
  </header>`;
}

/* ---------- section wrapper + annotations ---------- */

export function note(n, row, extra) {
  if (!row) return '';
  const behavior = row.parsed?.behavior || extra;
  return html`<aside class="note" aria-label="Annotation ${n}">
    <span class="note-pin">${n}</span>
    <div><strong>${row.section}</strong>${row.purpose ? html`<span> · ${txt(row.purpose)}</span>` : ''}
    ${behavior ? html`<em>Behavior: ${txt(behavior)}</em>` : ''}${row.ui ? html`<code>${row.ui}</code>` : ''}</div>
  </aside>`;
}

export function section({ id, cls = '', dark = false, grid = false, pin, row, extra, label }, inner) {
  const classes = ['s', dark && 's--dark', grid && 's--grid', cls].filter(Boolean).join(' ');
  return html`<section class="${classes}"${id ? raw(` id="${id}"`) : ''}${label ? raw(` aria-label="${label}"`) : ''} data-reveal>
    <div class="w">${pin ? note(pin, row, extra) : ''}${inner}</div>
  </section>`;
}

/* ---------- buttons ---------- */

export const btn = (label, { to = '#', kind = 'ink', arrow = false, attrs = '', size = '' } = {}) =>
  html`<a class="btn btn--${kind}${size ? ' btn--' + size : ''}" href="${to}"${raw(attrs ? ' ' + attrs : '')}><span>${label}</span>${arrow ? icon('arrow-right') : ''}</a>`;

export const buildTeamBtn = (kind = 'accent', size = '') =>
  html`<button type="button" class="btn btn--${kind}${size ? ' btn--' + size : ''}" data-open="dlg-team"><span>Build Your Team</span>${icon('arrow-right')}</button>`;

/* ---------- placeholders ---------- */

export const artPh = (label, { ratio = '16/9', tone = 'light', cls = '' } = {}) =>
  html`<figure class="ph ph--art ph--${tone} ${cls}" style="aspect-ratio:${ratio}">
    <figcaption>${icon('image')}<span><b>Art direction</b>${label}</span></figcaption>
  </figure>`;

export const awaitPh = (label, detail, { cls = '', ratio } = {}) =>
  html`<div class="ph ph--await ${cls}"${ratio ? raw(` style="aspect-ratio:${ratio}"`) : ''}>
    <p>${icon('hourglass-medium')}<span><b>Awaiting content</b>${label}</span></p>
    ${detail ? html`<small>${detail}</small>` : ''}
  </div>`;

/* ---------- chrome ---------- */

const MENUS = (structure) => [
  {
    label: 'Company', to: href('company'),
    links: [['About Us', '#/company'], ['Leadership', '#/company?at=leadership'], ['Our People', '#/company?at=people'], ['Methodologies', '#/company?at=methodologies'], ['Certifications', '#/company?at=awards']],
  },
  { label: 'Services', to: href('services'), mega: structure.services },
  {
    label: 'Expertise', to: href('industries'),
    links: [['Industries', href('industries')], ['Technologies', href('technologies')], ['Case Studies', href('case-studies')]],
  },
  { label: 'Insights', to: href('insights'), links: [['Blogs', href('insights')], ['Whitepapers', '#/insights?at=whitepapers']] },
  {
    label: 'Careers', to: href('careers'),
    links: [['Why Work With Us', '#/careers?at=vibes'], ['Open Positions', '#/careers?at=openings'], ['Internships & Talent Programs', '#/careers?at=internships'], ['Life at PTN', '#/careers?at=life']],
  },
];

export const logo = () =>
  html`<a class="logo" href="#/home" aria-label="PTN Global home"><img src="${LOGO}" alt="PTN Global" width="140" height="36"></a>`;

export function nav(structure, active) {
  const menus = MENUS(structure);
  const item = (m, i) => {
    const id = `menu-${i}`;
    const on = m.label === active ? ' is-active' : '';
    if (m.mega) {
      return html`<li class="nav-item${on}">
        <button class="nav-link" type="button" aria-expanded="false" aria-controls="${id}">${m.label}${icon('caret-down')}</button>
        <div class="mega" id="${id}" hidden>
          <div class="mega-in">
            ${m.mega.map((g) => html`<div class="mega-col">
              <a class="mega-cat" href="${href('services', { cat: g.items[0] && slugCat(g.category) })}">${icon(CATEGORY_ICON[g.category] || 'circle')}${g.category}</a>
              <ul>${g.items.map((s) => html`<li><a href="${href('service', { slug: s.slug })}">${s.name}</a></li>`)}</ul>
            </div>`)}
            <div class="mega-col mega-side">
              <a class="mega-cat" href="${href('services')}">${icon('squares-four')}All services</a>
              <ul><li><a href="#/services?at=engagement">Engagement Models</a></li><li><a href="#/services?at=roles">Offer Roles</a></li></ul>
            </div>
          </div>
        </div>
      </li>`;
    }
    return html`<li class="nav-item${on}">
      <button class="nav-link" type="button" aria-expanded="false" aria-controls="${id}">${m.label}${icon('caret-down')}</button>
      <ul class="drop" id="${id}" hidden>${m.links.map(([l, to]) => html`<li><a href="${to}">${l}</a></li>`)}</ul>
    </li>`;
  };
  return html`<div class="announce"><p>ISO/IEC 27001:2022 certified by CPG. Quality-managed delivery from Can Tho, Vietnam. <a href="#/company?at=awards">See our certifications ${icon('arrow-right')}</a></p></div>
  <header class="nav" data-nav>
    <div class="nav-in">
      ${logo()}
      <nav aria-label="Main"><ul class="nav-list">${menus.map(item)}</ul></nav>
      <div class="nav-cta">
        ${btn('Contact Us', { to: href('contact'), kind: 'line', size: 'sm' })}
        ${buildTeamBtn('ink', 'sm')}
        <button class="nav-burger" type="button" aria-expanded="false" aria-controls="mnav" aria-label="Open menu">${icon('list')}</button>
      </div>
    </div>
    <div class="mnav" id="mnav" hidden>
      ${menus.map((m) => html`<details><summary>${m.label}${icon('caret-down')}</summary><ul>
        ${m.mega ? m.mega.map((g) => html`<li class="mnav-cat">${g.category}</li>${g.items.map((s) => html`<li><a href="${href('service', { slug: s.slug })}">${s.name}</a></li>`)}`) : m.links.map(([l, to]) => html`<li><a href="${to}">${l}</a></li>`)}
      </ul></details>`)}
      <div class="mnav-cta">${btn('Contact Us', { to: href('contact'), kind: 'line' })}${buildTeamBtn('ink')}</div>
    </div>
  </header>`;
}

export const slugCat = (c) => c.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export function footer(structure) {
  const col = (t, links) => html`<div class="f-col"><h3>${t}</h3><ul>${links.map(([l, to]) => html`<li><a href="${to}">${l}</a></li>`)}</ul></div>`;
  return html`<footer class="footer">
    <div class="w footer-in">
      <div class="f-brand">
        ${logo()}
        <p>Software outsourcing from Vietnam, led from Melbourne.</p>
      </div>
      ${col('Services', structure.services.map((g) => [g.category, href('services', { cat: slugCat(g.category) })]))}
      ${col('Expertise', [['Industries', href('industries')], ['Technologies', href('technologies')], ['Case Studies', href('case-studies')]])}
      ${col('Company', [['About Us', href('company')], ['Insights', href('insights')], ['Careers', href('careers')], ['Contact', href('contact')]])}
      <div class="f-col f-side">
        <ul class="f-offices" aria-label="Offices">
          ${[['au', 'Australia', 'Head office', 'Level 5, 335 Flinders Lane, Melbourne VIC 3000'], ['vn', 'Vietnam', 'Development center', '13 Tran Binh Trong Street, Ninh Kieu District, Can Tho City']].map(([cc, c, r, a]) => html`<li>
            <p class="f-country"><img src="https://flagcdn.com/w40/${cc}.png" alt="" width="20" height="14" loading="lazy"><b>${c}</b><span>${r}</span></p>
            <p class="f-addr">${icon('map-pin')}${a}</p></li>`)}
        </ul>
        <div class="f-badges">
          <a class="f-badge" href="${CPG_VERIFY}" target="_blank" rel="noopener" aria-label="ISO/IEC 27001:2022 certified, verify certificate">
            <span class="iso-mark"><b>ISO</b><span>27001</span></span>
          </a>
          <a class="f-badge" href="${CPG_VERIFY}" target="_blank" rel="noopener" aria-label="Certified by CPG, Certification Partner Global">
            <img src="https://static.wixstatic.com/media/67e39e_4dc4d451a5fb49e49002dd4be6fce7f7~mv2.jpg/v1/fill/w_212,h_124,al_c,q_85,enc_auto/cpg.jpg" alt="" width="106" height="62" loading="lazy">
          </a>
          <p class="f-badge-note">ISO/IEC 27001:2022 · Certificate ISMS/20/R84/1419 · <a href="${CPG_VERIFY}" target="_blank" rel="noopener">Verify</a></p>
        </div>
        <div class="f-contact">
          <a href="${CONTACT.phoneHref}">${icon('phone')}${CONTACT.phone}</a>
          <a href="mailto:${CONTACT.email}">${icon('envelope-simple')}${CONTACT.email}</a>
        </div>
      </div>
    </div>
    <div class="w footer-base">
      <p>© 2021 PTN GLOBAL, All Rights Reserved.</p>
      <ul class="f-social" aria-label="Social media">
        ${[['linkedin-logo', 'LinkedIn', 'https://www.linkedin.com/company/ptn-global/'], ['facebook-logo', 'Facebook', 'https://www.facebook.com/ptnglobal']].map(([i, l, u]) => html`<li><a href="${u}" target="_blank" rel="noopener" aria-label="PTN GLOBAL on ${l}">${icon(i)}</a></li>`)}
      </ul>
      <p><a href="https://www.ptnglobalcorp.com/privacy" target="_blank" rel="noopener">Privacy Policy</a></p>
    </div>
    <p class="f-giant" aria-hidden="true">PTN GLOBAL</p>
  </footer>`;
}

/* ---------- heroes ---------- */

export function heroSplit({ pin, row, eyebrow: eb, title, accent, lead, actions, badge, media, backdrop }) {
  return section({ cls: 's--hero', grid: true, pin, row, label: 'Introduction' }, html`
    <div class="hero">
      <div class="hero-top${backdrop ? ' hero-top--flow' : ''}">
        ${backdrop || ''}
        <div>${eyebrow(eb)}<h1 class="display display--1">${splitTitle(title, accent)}</h1></div>
        ${badge ? html`<div class="hero-badge">${badge}</div>` : ''}
      </div>
      <div class="hero-row">
        <div class="hero-ctas">${actions}</div>
        ${lead ? html`<p class="hero-lead">${txt(lead)}</p>` : ''}
      </div>
      ${media ? html`<div class="hero-media">${media}</div>` : ''}
    </div>`);
}

export function heroPanel({ pin, row, title, accent, lead, actions, art, media }) {
  return section({ cls: 's--hero s--panel', pin, row, label: 'Introduction' }, html`
    <div class="panel-stage">
      ${media ? html`<div class="panel-bg panel-bg--photo">${media}</div>` : artPh(art, { ratio: 'auto', tone: 'deep', cls: 'panel-bg' })}
      <div class="panel">
        <h1 class="display display--1">${splitTitle(title, accent)}</h1>
        ${lead ? html`<p class="lead">${txt(lead)}</p>` : ''}
        ${actions ? html`<div class="s-actions s-actions--center">${actions}</div>` : ''}
      </div>
    </div>`);
}

export function heroTitle({ pin, row, eyebrow: eb, title, accent, lead, aside, actions }) {
  return section({ cls: 's--hero s--title', grid: true, pin, row, label: 'Introduction' }, html`
    <div class="title-hero">
      <div>${eyebrow(eb)}<h1 class="display display--1">${splitTitle(title, accent)}</h1>
      ${lead ? html`<p class="lead">${txt(lead)}</p>` : ''}
      ${actions ? html`<div class="s-actions">${actions}</div>` : ''}</div>
      ${aside ? html`<div class="title-aside">${aside}</div>` : ''}
    </div>`);
}

/* ---------- content blocks ---------- */

/** Ruled index list: big serif name, description, meta, arrow. */
export const indexList = (rows) =>
  html`<ol class="index">${rows.map((r) => html`<li><a class="index-row" href="${r.to}">
    <span class="index-ic">${icon(r.icon || 'arrow-up-right')}</span>
    <span class="index-name">${r.title}</span>
    <span class="index-text">${txt(r.text)}</span>
    <span class="index-meta">${r.meta || ''}${icon('arrow-right')}</span>
  </a></li>`)}</ol>`;

/** Sticky heading on the left, stacked blocks on the right. */
export const stickySplit = (left, blocks) =>
  html`<div class="sticky-split"><div class="sticky-left">${left}</div>
    <div class="stack">${blocks.map((b) => html`<article class="stack-item">
      ${b.icon ? html`<span class="stack-ic">${icon(b.icon)}</span>` : ''}
      <h3 class="h3">${txt(b.name)}</h3><p>${txt(b.text)}</p>${b.extra || ''}
    </article>`)}</div></div>`;

/** Ruled grid of items. */
export const ruledGrid = (items, { cols = 3, iconFor, numbered = false, cls = '' } = {}) =>
  html`<ul class="rgrid rgrid--${cols} ${cls}">${items.map((it, i) => html`<li class="rcell">
    ${numbered ? html`<span class="rnum">${String(i + 1).padStart(2, '0')}</span>` : iconFor ? html`<span class="ric">${icon(iconFor(it, i))}</span>` : ''}
    ${it.name ? html`<h3 class="h4">${txt(it.name)}</h3>` : ''}
    ${it.text ? html`<p>${txt(it.text)}</p>` : ''}
    ${it.to ? html`<a class="rlink" href="${it.to}">${it.linkLabel || 'Explore'}${icon('arrow-right')}</a>` : ''}
  </li>`)}</ul>`;

/** Tech stack: numbered category list + logo tiles (Simple Icons, monogram fallback). */
export function techTabs(cats, id = 'tech') {
  const list = cats.filter((c) => c.name);
  const items = (c) => splitTech(c.text);
  return html`<div class="stack-tabs" data-tabs>
    <div class="stack-list" role="tablist" aria-label="Technology categories" aria-orientation="vertical">
      ${list.map((c, i) => html`<button role="tab" id="${id}-t${i}" aria-controls="${id}-p${i}" aria-selected="${i === 0}" tabindex="${i === 0 ? 0 : -1}"${c.suggested ? raw(' class="is-suggested"') : ''}>
        <span class="stack-n">${String(i + 1).padStart(2, '0')}</span><span>${c.name}</span><span class="stack-c">${items(c).length}</span></button>`)}
    </div>
    ${list.map((c, i) => html`<div class="stack-panel" role="tabpanel" id="${id}-p${i}" aria-labelledby="${id}-t${i}" tabindex="0"${i ? raw(' hidden') : ''}>
      <header><h3 class="h3">${c.name}</h3>${c.suggested ? html`<span class="sample-flag">Suggested addition</span>` : html`<small>${items(c).length} technologies</small>`}</header>
      <ul class="tiles">${items(c).map(techTile)}</ul>
    </div>`)}
  </div>`;
}

/** Certificates wall: verified credentials first, then awards still owed. */
export function certWall({ awards = 2 } = {}) {
  return html`<div class="certs">
    ${CERTS.map((c) => html`<article class="cert-card cert-card--${c.status}">
      <div class="cert-top">
        <span class="cert-seal"><b>ISO</b>${c.std.replace(/^ISO(\/IEC)?\s*/, '')}</span>
        ${c.logo ? html`<img class="cert-issuer-logo" src="${c.logo}" alt="${c.issuer}" loading="lazy">` : ''}
      </div>
      <h3 class="h4">${c.title}</h3>
      <dl class="cert-meta"><div><dt>Standard</dt><dd>${c.std}</dd></div><div><dt>Issued by</dt><dd>${c.issuer}</dd></div><div><dt>Certificate</dt><dd>${c.no}</dd></div></dl>
      <ul class="cert-scope">${c.scope.map((x) => html`<li>${icon('check')}${x}</li>`)}</ul>
      <p class="cert-note">${icon(c.status === 'verified' ? 'seal-check' : 'warning-circle')}${c.note}</p>
    </article>`)}
    ${Array.from({ length: awards }, (_, i) => awaitPh(`Award or ranking ${i + 1}`, 'Request open: awards and certificates list (e.g. partner programs, review-platform rankings, workplace awards).'))}
  </div>`;
}

/** Logo marquee (TestSprite pattern): a row of ruled cells scrolling forever, faded at both edges.
    The set is rendered twice so the loop is seamless; the copy is hidden from assistive tech. */
export function clientStrip() {
  const cells = () => html`${CLIENTS.map((c) => html`<li class="client"><img src="${c.logo}" alt="${c.name}" loading="lazy"></li>`)}${[2, 3, 4, 5, 6, 7, 8].map((i) => html`<li class="client client--await"><span>Client logo ${i}</span></li>`)}`;
  return html`<div class="clients">
    <p class="clients-label"><span aria-hidden="true">// </span>Trusted by teams in Australia, New Zealand and beyond</p>
    <div class="marquee" data-marquee>
      <ul class="marquee-track">${cells()}</ul>
      <ul class="marquee-track" aria-hidden="true">${cells()}</ul>
    </div>
  </div>`;
}

export function testimonialFeature() {
  const t = TESTIMONIAL;
  return html`<div class="quotes quotes--feature">
    <figure class="quote quote--accent quote--lead">
      <span class="q-mark" aria-hidden="true">“</span>
      <blockquote>${t.quote}</blockquote>
      <figcaption class="q-meta"><img class="q-logo" src="${CLIENTS[0].logo}" alt="" loading="lazy"><div>${t.name}<span>${t.role}, ${t.company} (${t.country})</span></div></figcaption>
    </figure>
    ${[1, 2].map(() => html`<figure class="quote">
      <span class="q-flag">Awaiting testimonial</span>
      <blockquote>Client quote, up to three lines, from the testimonial list PTN provides.</blockquote>
      <figcaption class="q-meta"><span class="q-av" aria-hidden="true"></span><div>Client name<span>Role, Company</span></div></figcaption>
    </figure>`)}
  </div>`;
}

/** Numbered process. Sequence carries meaning, so numbers stay. */
export const steps = (items, { dark = false, layout = 'row' } = {}) =>
  html`<ol class="steps steps--${layout}${dark ? ' steps--dark' : ''}">${items.map((s, i) => html`<li>
    <span class="step-n">${String(i + 1).padStart(2, '0')}</span>
    <h3 class="h4">${txt(s.name)}</h3>
    ${s.text ? html`<p>${txt(s.text)}</p>` : ''}
  </li>`)}</ol>`;

export const faq = (items) =>
  html`<div class="faq">${items.map((f, i) => html`<details${i === 0 ? raw(' open') : ''}>
    <summary><span>${txt(f.q)}</span>${icon('plus')}</summary><div class="faq-a"><p>${txt(f.a)}</p></div>
  </details>`)}</div>`;

export const caseCard = (i, { to = href('case-study', { slug: 'sample' }), item } = {}) =>
  html`<article class="case">
    ${item?.photo ? html`<figure class="case-photo">${photo(item.photo, { w: 900, h: 675 })}</figure>` : stock(`case-${i}`, 'Stock image standing in for a case study cover', { ratio: '4/3', label: 'Case study cover' })}
    <div class="case-body">
      <p class="case-tag">${item?.tag || 'Industry · Service'}</p>
      <h3 class="h4">${item?.title || 'Case study title awaiting'}</h3>
      <p>${item?.text || 'Client story, challenge and measurable result will come from the case study list.'}</p>
      ${item?.flag ? html`<span class="sample-flag">${item.flag}</span>` : ''}
      <a class="rlink" href="${to}">Explore more${icon('arrow-right')}</a>
    </div>
  </article>`;

export const rail = (cards, label = 'Carousel') =>
  html`<div class="rail" data-rail>
    <div class="rail-track" tabindex="0" role="region" aria-label="${label}">${cards}</div>
    <div class="rail-ctl"><button type="button" data-rail-prev aria-label="Previous">${icon('arrow-left')}</button><button type="button" data-rail-next aria-label="Next">${icon('arrow-right')}</button></div>
  </div>`;

export const newsCard = (i, kind = 'Blog', to = href('blog'), title) => {
  const topic = title || TOPICS.filter((t) => t[0] === kind)[i % Math.max(1, TOPICS.filter((t) => t[0] === kind).length)]?.[1] || TOPICS[i % TOPICS.length][1];
  return html`<article class="news">
    ${stock(`${kind}-${i}`, `Stock image for ${kind.toLowerCase()} post`, { ratio: '16/10', label: `${kind} cover` })}
    <p class="news-meta"><span>${kind}</span><em>Suggested topic</em></p>
    <h3 class="h4"><a href="${to}">${topic}</a></h3>
  </article>`;
};

export function ctaFinale({ pin, row }) {
  const c = row?.parsed || {};
  return section({ cls: 's--finale', pin, row, id: 'contact-cta', label: 'Contact' }, html`
    <div class="finale">
      <div class="finale-bg finale-bg--photo">${photo('teamGroup', { w: 2000, h: 1100, pos: 'center 40%' })}</div>
      <div class="finale-panel">
        <h2 class="display display--2">${splitTitle(c.title || 'Big projects always start through a simple conversation.', 'a simple conversation.')}</h2>
        ${c.subtitle ? html`<p class="lead">${txt(c.subtitle)}</p>` : ''}
        <dl class="finale-contact">
          <div><dt>Phone</dt><dd><a href="${CONTACT.phoneHref}">${CONTACT.phone}</a></dd></div>
          <div><dt>Email</dt><dd><a href="mailto:${CONTACT.email}">${CONTACT.email}</a></dd></div>
        </dl>
        <div class="s-actions s-actions--center">${btn('Contact Us', { to: href('contact'), kind: 'accent', arrow: true })}</div>
      </div>
    </div>`);
}

/* ---------- dialogs ---------- */

export const dialogs = () => html`
<dialog class="dlg" id="dlg-team" aria-labelledby="dlg-team-t">
  <form method="dialog" class="dlg-in" data-team-form novalidate>
    <header class="dlg-head"><h2 class="h3" id="dlg-team-t">Build your team</h2><button class="icon-btn" value="cancel" aria-label="Close">${icon('x')}</button></header>
    <p class="dlg-lead">Tell us the roles you need. We reply with a team proposal and indicative pricing.</p>
    <fieldset class="field"><legend>Roles</legend>
      <div class="pills">${['Full Stack Developer', 'Mobile App Developer', 'DevOps Engineer', 'Software Tester', 'UI/UX Designer', 'Business Analyst', 'Project Manager', 'Data Analyst'].map((r) => html`<label class="pill"><input type="checkbox" name="roles" value="${r}"><span>${r}</span></label>`)}</div>
    </fieldset>
    <div class="field-row">
      <label class="field"><span>Team size</span><select name="size"><option>1-2</option><option selected>3-5</option><option>6-10</option><option>10+</option></select></label>
      <label class="field"><span>Engagement model</span><select name="model"><option>Dedicated Team</option><option>Staff Augmentation</option><option>Time &amp; Material</option><option>Fixed Price</option><option>Offshore Development Center</option></select></label>
    </div>
    <label class="field"><span>Work email</span><input name="email" type="email" autocomplete="email" required><small class="err" hidden></small></label>
    <footer class="dlg-foot"><button class="btn btn--line" value="cancel">Cancel</button><button class="btn btn--accent" value="send" data-team-submit><span>Send request</span>${icon('arrow-right')}</button></footer>
    <p class="dlg-done" hidden role="status">${icon('check-circle')} Request captured. In the live site this goes to ${CONTACT.email}.</p>
  </form>
</dialog>
<dialog class="dlg dlg--video" id="dlg-video" aria-label="Video player">
  <div class="dlg-in">
    <header class="dlg-head"><h2 class="h3" data-video-title>PTN Global video</h2><form method="dialog"><button class="icon-btn" aria-label="Close">${icon('x')}</button></form></header>
    ${awaitPh('Company video file', 'Request open: "Please provide us with the videos you would like to show to users."', { ratio: '16/9' })}
  </div>
</dialog>`;
