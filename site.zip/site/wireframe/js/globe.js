// Hero globe: a still, hairline orthographic view (dot-matrix land) with great-circle links from the Can Tho hub to the markets PTN serves.
// Markets from ptnglobalcorp.com/job-board ("customers from Australia, New Zealand, and other English-speaking
// countries in North America and Europe"; stakeholders "from Australia, New Zealand, UK and US").
// Libraries load lazily from jsDelivr; if they fail, the static panel stays.
import { html, icon } from './dom.js';

const HUB = { name: 'Can Tho', role: 'Development center', at: [105.78, 10.04] };
const PLACES = [
  { name: 'Ho Chi Minh City', role: 'Office', at: [106.66, 10.76], from: 'hub', small: true },
  { name: 'Melbourne', role: 'Head office', at: [144.96, -37.81], from: 'hub', office: true, side: 'left' },
  { name: 'Auckland', role: 'New Zealand clients', at: [174.76, -36.85], from: 'hub', side: 'right', dy: 26 },
  { name: 'London', role: 'UK clients', at: [-0.13, 51.51], from: 'hub' },
  { name: 'New York', role: 'US clients', at: [-74.0, 40.71], from: 'hub' },
];

export function globePanel() {
  return html`<div class="globe" data-globe>
    <canvas class="globe-canvas" aria-hidden="true"></canvas>
    <div class="globe-copy">
      <p class="globe-eyebrow">// Global delivery</p>
      <h2 class="globe-kicker">One delivery hub, <em>clients across four markets</em></h2>
      <dl class="globe-stats">
        <div><dt class="vh">Client markets</dt><dd><b>4</b><span>Client markets</span></dd></div>
        <div><dt class="vh">Offices</dt><dd><b>3</b><span>Offices</span></dd></div>
        <div><dt class="vh">Head office</dt><dd><b>AU</b><span>Head office</span></dd></div>
      </dl>
    </div>
    <p class="vh">Map showing PTN Global's development center in Can Tho, Vietnam, its head office in Melbourne, and client markets in Australia, New Zealand, the United Kingdom and the United States.</p>
  </div>`;
}

let libs;
const load = () =>
  (libs ||= Promise.all([
    import('https://cdn.jsdelivr.net/npm/d3-geo@3/+esm'),
    import('https://cdn.jsdelivr.net/npm/topojson-client@3/+esm'),
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json').then((r) => r.json()),
  ]));


export async function bindGlobe(root) {
  const el = root.querySelector('[data-globe]');
  if (!el) return;
  let d3, topo, world;
  try {
    [d3, topo, world] = await load();
  } catch {
    el.classList.add('is-static');
    return;
  }
  const land = topo.feature(world, world.objects.land);
  const canvas = el.querySelector('canvas');
  const ctx = canvas.getContext('2d');
  const proj = d3.geoOrthographic().clipAngle(90).rotate([-138, 30, 0]);
  const path = d3.geoPath(proj, ctx);
  const grat = d3.geoGraticule().step([15, 15])();
  const ACC = '#4FC3EC';

  // Land as a fine dot matrix (computed once): lighter than a filled silhouette.
  const dots = [];
  for (let lat = -58; lat <= 78; lat += 1.6) {
    const step = 1.6 / Math.max(0.25, Math.cos((lat * Math.PI) / 180));
    for (let lon = -180; lon < 180; lon += step) if (d3.geoContains(land, [lon, lat])) dots.push([lon, lat]);
  }
  const arcs = PLACES.map((p) => ({ ...p, line: { type: 'LineString', coordinates: Array.from({ length: 51 }, (_, k) => d3.geoInterpolate(HUB.at, p.at)(k / 50)) } }));
  const center = () => { const r = proj.rotate(); return [-r[0], -r[1]]; };
  const facing = (ll) => d3.geoDistance(ll, center()) < Math.PI / 2 - 0.03;

  let W = 0, H = 0, R = 0, dpr = 1;
  function draw() {
    const r = el.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    W = r.width; H = r.height;
    canvas.width = W * dpr; canvas.height = H * dpr;
    const narrow = W < 900;
    // Oversized sphere that bleeds off the bottom edge: reads as a horizon, not a sticker in a box.
    R = narrow ? W * 0.7 : Math.min(W * 0.34, H * 0.76);
    proj.scale(R).translate([narrow ? W * 0.55 : W * 0.66, narrow ? H * 0.5 + R * 0.62 : H * 0.5 + R * 0.42]);

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.beginPath(); path({ type: 'Sphere' }); ctx.strokeStyle = 'rgba(79,195,236,.35)'; ctx.lineWidth = 0.75; ctx.stroke();
    ctx.beginPath(); path(grat); ctx.strokeStyle = 'rgba(255,255,255,.05)'; ctx.lineWidth = 0.5; ctx.stroke();

    ctx.fillStyle = 'rgba(150,212,236,.78)';
    for (const d of dots) {
      if (!facing(d)) continue;
      const [x, y] = proj(d);
      if (x < -2 || y < -2 || x > W + 2 || y > H + 2) continue;
      ctx.fillRect(x - 0.75, y - 0.75, 1.5, 1.5);
    }

    arcs.forEach((a) => {
      ctx.beginPath(); path(a.line);
      ctx.strokeStyle = a.office ? 'rgba(255,255,255,.85)' : ACC; ctx.globalAlpha = a.small ? 0.5 : 0.8; ctx.lineWidth = 0.9; ctx.stroke(); ctx.globalAlpha = 1;
      if (!facing(a.at)) return;
      const [x, y] = proj(a.at);
      if (x < 0 || y < 0 || x > W || y > H) return;
      ctx.beginPath(); ctx.arc(x, y, 2.5, 0, Math.PI * 2); ctx.fillStyle = a.office ? '#fff' : ACC; ctx.fill();
      if (!a.small) label(x, y, a.name, a.role, a.side === 'left');
    });

    if (facing(HUB.at)) {
      const [x, y] = proj(HUB.at);
      ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.strokeStyle = 'rgba(79,195,236,.5)'; ctx.lineWidth = 0.75; ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y, 3.2, 0, Math.PI * 2); ctx.fillStyle = ACC; ctx.fill();
      label(x, y, HUB.name, HUB.role, false);
    }
  }

  // Hairline tick + two lines of text, no boxes.
  function label(x, y, name, role, left) {
    ctx.font = '500 12.5px Satoshi, sans-serif';
    const w = Math.max(ctx.measureText(name).width, ctx.measureText(role).width * 0.95);
    if (!left && x + 38 + w > W - 8) left = true;
    const dx = left ? -1 : 1, x1 = x + dx * 14, y1 = y - 14;
    ctx.beginPath(); ctx.moveTo(x + dx * 4, y - 4); ctx.lineTo(x1, y1); ctx.lineTo(x1 + dx * 18, y1);
    ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 0.75; ctx.stroke();
    ctx.textAlign = left ? 'right' : 'left';
    const tx = Math.max(8, Math.min(W - 8, x1 + dx * 24));
    ctx.fillStyle = '#fff'; ctx.font = '500 12.5px Satoshi, sans-serif'; ctx.fillText(name, tx, y1 + 4);
    ctx.fillStyle = 'rgba(159,179,188,.9)'; ctx.font = '400 9.5px "IBM Plex Mono", monospace'; ctx.fillText(role.toUpperCase(), tx, y1 + 17);
    ctx.textAlign = 'left';
  }

  draw();
  new ResizeObserver(draw).observe(el);
  document.fonts?.ready.then(draw);
  el.classList.add('is-live');
}
