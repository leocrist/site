// Tiny HTML-string helpers. `html` escapes interpolations; nest with `html` or wrap with `raw`.

class Raw {
  constructor(s) { this.s = s; }
  toString() { return this.s; }
}

export const raw = (s) => new Raw(String(s ?? ''));

export const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const fmt = (v) => {
  if (v == null || v === false || v === true) return '';
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(fmt).join('');
  return esc(v);
};

export const html = (strings, ...vals) =>
  raw(strings.reduce((out, s, i) => out + s + (i < vals.length ? fmt(vals[i]) : ''), ''));

/** Normalise doc copy for display: dashes used as pauses become commas, whitespace collapses. */
export const txt = (s) =>
  String(s ?? '')
    .replace(/\s+[—–]\s+/g, ', ')
    .replace(/[—–]/g, '-')
    .replace(/\s+/g, ' ')
    .trim();

export const icon = (name, label) =>
  label
    ? html`<i class="ph-light ph-${name}" role="img" aria-label="${label}"></i>`
    : html`<i class="ph-light ph-${name}" aria-hidden="true"></i>`;
