---
title: "Insight Layout"
confluence_page_id: "63308442"
confluence_space: "IN"
parent: "All New Website"
sort_order: 10
doc_path: "All New Website/Insight Layout.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308442/Insight+Layout"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar | Main navigation bar with links to key sections of the website. | Title: PTN Global’s Insight |  |
| Blog List Section | Hero section with a catchy tagline, a high-quality background image, and a clear call-to-action button. | Title: Our Blog Subtitle: # Content: - Filter: Blog - News - Events - A search for users to search - A page will include 12 sections | Hero section.png |
| Our Whitepapers | Overview of the different services or topics the company covers, presented with short descriptions. | Title: Our Whitepapers Subtitle: # Content: - Filter: Waiting - A search for users to search - A page will include 12 sections | Our blog.png |
| Footer | Contains essential links, company information, contact details, and social media connections. |  | Footer.png |

## Full UI:

[Insights.jpg](https://ptnglobal.sharepoint.com/:i:/s/delivery/EXKzEJmkhqpIrnGi3U_RYsABCnZIVr-7XpHOk5TwhSzt-A?e=CopxWl)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the behavior |  |
| Please provide your expectation of the filters in the our whitepapers and our blogs |  |
