---
title: "Blogs Details"
confluence_page_id: "63308454"
confluence_space: "IN"
parent: "All New Website"
sort_order: 11
doc_path: "All New Website/Blogs Details.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308454/Blogs+Details"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar | Main navigation bar with links to key sections of the website. |  |  |
| Hero Section | Hero section with a catchy tagline, a high-quality background image, and a clear call-to-action button. | Title: {Title of the blog}Subtitle: - Created date: dd/mm/yyyy - Minute read | Hero section.png |
| Content | Overview of the different services or topics the company covers, presented with short descriptions. |  | Content.png |
| Suggested Blogs | Show the suggested blogs | Title: Suggested Blogs Behavior: - Show 3 latest blogs that related to that category | Suggested blog.png |
| Footer | Contains essential links, company information, contact details, and social media connections. |  | Footer.png |

## Full UI:

[Blog Details.jpg](https://ptnglobal.sharepoint.com/:i:/s/delivery/EbX-hYh36VpOoQ9y3Wi34mgBv0RxsQg0TljC42r-GXDaUA?e=90QQnp)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the behavior and wireframe |  |
