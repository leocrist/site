---
title: "All New Website"
confluence_page_id: "63308107"
confluence_space: "IN"
doc_path: "All New Website/README.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308107/All+New+Website"
provenance: confluence-export
---

# All New Website

Index of Confluence pages exported under this folder (same order as the Confluence page tree).

## Pages

1. [Website Structure](Website Structure.md) — `63308109`
2. [Home Page Layout](Home Page Layout.md) — `63308158`
3. [Company Layout](Company Layout.md) — `63308397`
4. [Service Overall Layout](Service Overall Layout.md) — `63308404`
5. [Industries Layout](Industries Layout.md) — `63308412`
6. [Technologies Layout](Technologies Layout.md) — `63308775`
7. [Case Studies Layout](Case Studies Layout.md) — `63308780`
8. [Career Layout](Career Layout.md) — `63308429`
9. [Career Detail Layout](Career Detail Layout.md) — `63308436`
10. [Insight Layout](Insight Layout.md) — `63308442`
11. [Blogs Details](Blogs Details.md) — `63308454`
12. [Whitepaper Details](Whitepaper Details.md) — `63308459`
13. [Service Details](Service Details.md) — `63308464`

## Service Details (child pages)

- [Custom Software Development Content](Service Details/Custom Software Development Content.md)
- [Web Application Development Content](Service Details/Web Application Development Content.md)
- [Mobile Application Development Content](Service Details/Mobile Application Development Content.md)
- [Desktop Application Development Content](Service Details/Desktop Application Development Content.md)
- [Enterprise Application Development Content](Service Details/Enterprise Application Development Content.md)
- [API Development & Integration Content](Service Details/API Development & Integration Content.md)
- [Product Engineering Services Content](Service Details/Product Engineering Services Content.md)
- [AI & Machine Learning Solutions Content](Service Details/AI & Machine Learning Solutions Content.md)
- [Data Science & Big Data Solutions Content](Service Details/Data Science & Big Data Solutions Content.md)
- [Generative AI Application Development Content](Service Details/Generative AI Application Development Content.md)
