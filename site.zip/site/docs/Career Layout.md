---
title: "Career Layout"
confluence_page_id: "63308429"
confluence_space: "IN"
parent: "All New Website"
sort_order: 8
doc_path: "All New Website/Career Layout.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308429/Career+Layout"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar |  | The navigation bar to navigate to other pages |  |
| Hero Section | An engaging hero area featuring a catchy tagline, high-quality background image, and a clear call-to-action button. | Title: Help us shape an industry. Subtitle: Be part of a team that drives innovation, challenges limits, and creates solutions that transform businesses worldwide. CTA: - Browse jobs → Click to it it to navigate to the "Choose your next career opportunity" section | Hero section.png |
| End-to-end good vibes | A brief overview of the company’s services and culture, highlighting what makes it a great place to work. | Title: End-to-end good vibes Subtitle: # Content: - We believe that a positive workplace drives success. From your first day with us, you will experience an open, supportive, and collaborative culture where respect, trust, and teamwork come first. Whether it’s celebrating milestones, sharing wins, or simply creating an enjoyable daily work environment, we make sure that good vibes flow through every part of your journey with us. | End to end good vibes.png |
| Choose your next career opportunity | Display all current job openings with titles, locations, and application links. | Title: Choose your next career opportunity Subtitle: # Content: - Filter:Jobs Back End Developers - Front End Developers - DevOps - Tester - Business Analyst - UX UI Designer - Full Stack Developers - Data Analyst - Other - Level Senior - Middle - Junior - Fresher - OJT - Intern - A search bar to find positions - A list displaying job titles and the number of openings - Click on a job to view its details → Career details UI | Choose your next career opportunity.png |
| Our benefits | Highlight the benefits and perks employees enjoy when working at the company. | Title: What will you get when working with us? Subtitle: # Content - Section 1: Career Growth & Development We invest in your future. Through continuous training, workshops, and mentorship, you will have the resources and support to advance your skills and achieve your career goals. - Section 2: Challenging & Meaningful ProjectsYou will work on diverse projects that make a real impact, giving you the chance to solve complex problems and contribute to meaningful outcomes. - Section 3: Supportive Work EnvironmentCollaboration and teamwork are at the heart of our culture. We create an inclusive environment where your voice matters, and innovation is encouraged. - Section 4: Recognition & Advancement Hard work and dedication never go unnoticed. We recognize contributions and provide clear pathways for promotion and long-term growth. - Section 5: Work-Life Balance We believe in balance. With flexible policies and a culture of respect, we ensure you can succeed at work while also enjoying your personal life. - Section 6: Competitive Compensation & BenefitsWe provide fair pay, performance-based incentives, and benefits that support your overall well-being. | What will you get when working with us_.png |
| Our process | Explain the recruitment and onboarding process to give candidates a clear idea of what to expect. | Title: Here’s our hiring process Subtitle: # Content - Section 1: Application Review A member of our Talent Acquisition team will review your application and let you know if there’s a match! - Section 2: Intro Call This is our first opportunity to connect! We’ll chat a bit about your background - Section 3: Initial Interview We’ll dive deeper into your most recent experience and the qualifications of the role you've applied for. We want to learn about the accomplishments you're proud of and the challenges you've tackled that have contributed to your learning and growth. - Section 4: Assessment You’ll get an opportunity to showcase your skills based on some of the requirements of the role. - Section 5: Final Interview We'll end our process by diving into the rest of your experience so that we can understand your career journey so far and your goals for the future. - Section 6: OfferWe’ll make things official and welcome you to the team! | Here's our hiring process.png |
| Internships & Talent Programs | Overview of internship opportunities and talent development programs available for students and graduates. | Title : Internships & Talent Programs Subtitle: Start your career journey with us through our On-the-Job Training (OJT) and Internship Program. Over a 3-month period, you will gain practical experience, receive hands-on training, and work as part of our team. This program is designed to help you apply your knowledge, build professional skills, and grow in a real workplace environment. Outstanding participants may also be offered full-time employment after completion. CTA: - See the opportunity → Click to the button to navigate to the "Choose your next career opportunity" section with the Internship and OJT filter | Internship & talen programs.png |
| Life at PTN | Showcase the workplace culture at PTN with photos, stories, and testimonials from employees. | Title : Why do we go to work?Subtitle: # Content : - Include the pictures of PTN life to show - when users scroll down, the frame will scroll horizontally | Why do we go to work.png |
| Choose your next career opportunity (CTA Banner) | A dedicated banner encouraging visitors to apply now or explore open positions. | Title: Choose your next career opportunitySubtitle: # CTA: - Browse jobs → Click to it it to navigate to the "Choose your next career opportunity" section | CTA banner.png |
| Footer |  |  | Footer.png |

## Full UI:

[Career.jpg](https://ptnglobal.sharepoint.com/:i:/s/delivery/EQE79-eca6ZBut8LB2G-aToBgTpOEn3JJzC-WXtxacotiw?e=JkgOv1)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the content |  |
