---
title: "Website Structure"
confluence_page_id: "63308109"
confluence_space: "IN"
parent: "All New Website"
sort_order: 1
doc_path: "All New Website/Website Structure.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308109/Website+Structure"
provenance: confluence-export
---

# 1. Site Map

```css
Home (/)
|
├── Company (/company/)
|   ├── About Us (/company/about)
|   ├── Leadership (/company/leadership)
|   ├── Our People (/company/people)
|   ├── Methodologies (/company/methodologies)
|   └── Certifications (/company/certifications)
|
├── Services (/services/)
|   ├── Our Services (/services/...)
|   ├── Engagement Models (/services/engagement-models)
|	└── Offer Roles (/services/offer-roles)
|
├── Expertise (/expertise/)
|   ├── Industries (/expertise/industries/)
|   ├── Technologies (/expertise/technologies/)
|   └── Case Studies (/expertise/case-studies/)
|
├── Insights (/insights/)
|   ├── Blogs (/insights/blogs)
|   └── Whitepapers (/insights/whitepapers)
|
├── Careers (/careers/)
|   ├── Why Work With Us (/careers/why-work-with-us)
|   ├── Open Positions (/careers/open-positions)
|   ├── Internships & Talent Programs (/careers/internships)
|   └── Life at PTN (/careers/life-at-ptn)
|
└── Contact (/contact)
```

# 2. Pages Layout & Navigation

| # | Page | Layout Document | Description |
| --- | --- | --- | --- |
| 1 | Home | Home Page Layout |  |
| 2 | Company | Company Pages Layout | TODO: include the Cultural Diversity |
| 3 | Services |  |  |
| 4 | Expertise |  | TODO: Industries >> Page layout include existing domain and new domain |
| 5 | Insights |  | TODO: add feature filter by blogs, events, news |
| 6 | Careers |  |  |
| 7 | Contact |  | Inquiry / RFP form (multi-step lead form) Office Locations & Maps Partner with Us (strategic alliances) Social Media Links TODO: Include the get quote base on the tech & team size |

# 3. Navigation & Hierarchy

**Services**

| # | Category | Service | Description |
| --- | --- | --- | --- |
| 1 | Core Application Development | Custom Software Development | Tailor-made solutions designed to meet unique business requirements. |
| 2 | Web Application Development | Scalable and secure browser-based applications. |
| 3 | Mobile Application Development | Native and cross-platform apps for iOS, Android, and hybrid platforms. |
| 4 | Desktop Application Development | Robust applications for Windows, macOS, and Linux environments. |
| 5 | Enterprise Application Development | ERP, CRM, HRM, and SCM systems to streamline operations. |
| 6 | API Development & Integration | Secure APIs to connect and extend software functionality. |
| 7 | Product Engineering Services | End-to-end product lifecycle development from ideation to deployment. |
| 8 | Emerging Technologies | AI & Machine Learning Solutions | Smart apps with predictive analytics and automation. |
| 9 | Data Science & Big Data Solutions | Transform data into actionable insights and strategies. |
| 10 | Generative AI Application Development | Build apps powered by LLMs (Large Language Models) for text, code, and media generation with external knowledge bases for accurate, context-aware responses. |
| 11 | AI Agent & Autonomous Workflow Development | Create intelligent agents that automate multi-step tasks and decision-making. |
| 12 | Cloud & DevOps | Cloud-Native Application Development | Build apps optimized for cloud scalability and resilience. Build apps that auto-scale without managing servers. Develop subscription-based, multi-tenant software platforms. |
| 13 | DevOps Consulting & Automation | Automate software builds, testing, and deployments with CI/CD pipeline. Automate infrastructure provisioning using code. |
| 14 | Cloud Migration Services | Move legacy apps and data securely to cloud platforms. |
| 15 | Testing & Quality Assurance | Manual Testing | functional, regression, load testing. |
| 16 | Automated Testing | Selenium, Appium, Cypress solutions. |
| 17 | Performance Testing | Test and improve speed, scalability, and reliability. |
| 18 | Security Testing | Identify vulnerabilities and protect against threats. |
| 19 | Design, Support & Maintenance | UI/UX Design & Prototyping | User-centric designs, wireframes, and interactive prototypes. |
| 20 | Application Maintenance & Support | Continuous updates, monitoring, and technical support. |
| 21 | Legacy System Modernization | Upgrading old systems to new tech stacks. |
| 22 | System Integration Services | Connecting disparate business apps. |

**Engagement Models**

| # | Category | Model | Description |
| --- | --- | --- | --- |
| 1 | Innovation Models | AI-Augmented | Providers combine human development with AI tools (e.g., AI coding assistants, automated testing, CI/CD bots) as part of the engagement. |
| 2 | Innovation Partnership | The provider becomes a co-innovation partner, investing resources into building new solutions together. |
| 3 | Traditional Models | Fixed Price | The scope, timeline, and cost are agreed upon upfront. |
| 4 | Time & Material | The client pays for actual time spent and resources used. |
| 5 | Dedicated Team | A team (developers, QA, PMs) works exclusively on the client’s project, often managed jointly. |
| 6 | Staff Augmentation | The provider supplies additional engineers to extend the client's in-house team. |
| 7 | Build-Operate-Transfer | The service provider sets up a dedicated development center, operates it for a period, and eventually transfers ownership to the client. |
| 8 | Global Delivery Models | Offshore Development Center | A fully functional team in another country dedicated to the client, often managed like an extension of their company. |
| 9 | Onsite-Offshore | A few engineers work onsite with the client, while the rest operate offshore. |

**Industries**

| # | Category | Industry | Description |
| --- | --- | --- | --- |
| 1 | Finance & Business | Finance | Solutions for financial operations, analytics, and risk management. |
| 2 | Banking | Digital banking platforms, core banking systems, mobile banking apps. |
| 3 | Insurance | Claims automation, underwriting, and policy management platforms. |
| 4 | Investment & Wealth Management | Robo-advisors, trading platforms, and portfolio management tools. |
| 5 | Real Estate / Property | Property management, smart building solutions, and virtual tours. |
| 6 | Legal & Compliance | Contract automation, case management, and compliance monitoring. |
| 7 | Healthcare & Life Sciences | Healthcare | Telemedicine, EHR, patient portals, and hospital systems. |
| 8 | Biotechnology | Genomics, bioinformatics, and drug discovery platforms. |
| 9 | Pharmaceuticals | Clinical trial management, supply chain, and R&D systems. |
| 10 | Retail, Commerce & Consumer | Retail | POS systems, inventory management, and customer engagement apps. |
| 11 | E-commerce | Online marketplaces, shopping carts, and payment gateways. |
| 12 | Travel, Transport & Logistics | Travel & Hospitality | Booking engines, hotel management, and travel apps. |
| 13 | Logistics & Supply Chain | Fleet management, warehouse automation, and tracking. |
| 14 | Education & Knowledge | Education | E-learning platforms, virtual classrooms, and student management. |
| 15 | Corporate Training & Learning | LMS platforms and workforce skill development. |
| 16 | Research & Academia | Collaboration platforms and academic publishing tools. |
| 17 | Publishing & Media | Digital publishing, content distribution, and e-libraries. |
| 18 | Public Sector | Government | Citizen portals, e-government services, and digital IDs. |
| 19 | Telecommunications & Technology | Cloud & Data Centers | Cloud migration, monitoring, and data center automation. |
| 20 | Professional Services | Human Resources | Talent management, HRMS, and payroll platforms. |
| 21 | Marketing & Advertising | Campaign automation, CRM, and data-driven marketing. |
| 22 | Workforce Management | Scheduling, workforce analytics, and productivity tools. |
| 23 | Business Services | ERP, project management, and collaboration platforms. |

**Technologies**

| # | Category | Technology | Description | Examples |
| --- | --- | --- | --- | --- |
|  | AI & Machine Learning | Artificial Intelligence (AI) | Intelligent solutions for automation & decision-making. | TensorFlow, PyTorch, Scikit-learn |
|  |  | Generative AI (GenAI) |  |  |
|  |  | Large Language Models (LLMs) |  |  |
|  |  | Retrieval-Augmented Generation (RAG) |  |  |
|  |  | Natural Language Processing (NLP) |  |  |
|  |  | Computer Vision |  |  |
|  |  | Predictive Analytics |  |  |
|  |  | AI Agents & Autonomous Systems |  |  |
|  |  | Reinforcement Learning |  |  |
|  |  | Synthetic Data Generation |  |  |

**Offer Roles**
