---
title: "Technologies Layout"
confluence_page_id: "63308775"
confluence_space: "IN"
parent: "All New Website"
sort_order: 6
doc_path: "All New Website/Technologies Layout.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308775/Technologies+Layout"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar |  | The navigation bar to navigate to other pages |  |
| Hero Section | Engaging hero section with a catchy tagline, high-quality background image, and a clear call-to-action button. | Title: Our Engineering Tech Stack Subtitle: Developing software requires deep expertise and specialized knowledge. Anyone who has built a technology solution knows how crucial it is to choose the right technology stack. Below is an overview of the programming languages, frameworks, databases, and platforms our IT team leverages to deliver robust solutions. | Hero section.png |
| Our engineering tech stack | Presentation of the technologies, programming languages, frameworks, and tools PTN leverages to deliver innovative, scalable solutions. | Title: Our engineering tech stackSubtitle: Developing software requires deep expertise and specialized knowledge. Anyone who has built a technology solution knows how crucial it is to choose the right technology stack. Below is an overview of the programming languages, frameworks, databases, and platforms our IT team leverages to deliver robust solutions. Content: - Back End:Microsoft .NET / Node.js / Python - Front End:Angular / CSS3 / Ember / HTML5 / JavaScript / Meteor / React / Vue.js - AI & LLM:OpenAI / Claude / Gemini / Grok / DeepSeek / LangChain / TensorFlow - Automation: n8n / Dify / Azure AI Studio / Power Automate - Mobile: Android / Flutter / iOS / PWA / React Native / Xamarin - Clouds:AWS / Azure / DigitalOcean / Google Developer Tools / Rackspace - Big Data / NoSQL:Amazon DocumentDB / Amazon DynamoDB / Cassandra / Amazon Redshift / Apache Hive / Apache Kafka / Apache Spark / Apache ZooKeeper / Amazon ElastiCache / Azure Blob Storage / Azure Cosmos DB / Azure Data Lake / Google Cloud Datastore / Hadoop / Apache HBase / MongoDB - DevOps: Ansible / Chef / Docker / Kubernetes / Mesos / OpenShift / Packer / Puppet / SaltStack / Terraform - CI/CD Tools:AWS Developer Tools / Azure DevOps / Jenkins / TeamCity / Travis CI / Google Developer Tools / GitHub - Monitoring:Datadog / Elasticsearch / Grafana / Nagios / Prometheus / Zabbix - Test Automation Tools: Apache JMeter / Appium / CUIT / FMBT / HP Quick Test Professional / Postman / Protractor / Ranorex / Selenium / TestComplete / TestStack White / Unified Functional Testing / XCTest - Information Security: Acunetix / Burp Suite / Cloudflare / Masscan / Metasploit / Nessus / Nmap / Radar / Siege | Our engineering tech stack.png |
| Footer | Include company info, quick links, social media, and contact details. |  | Footer.png |

## Full UI:

[Technology.png](https://ptnglobal.sharepoint.com/:i:/s/delivery/EeppCPwdcOhLlMm8_ZkWMIABx9Sfhyph9FTcgCAMX39y8w?e=5sQ4ai)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the content |  |
