---
title: "Case Studies Layout"
confluence_page_id: "63308780"
confluence_space: "IN"
parent: "All New Website"
sort_order: 7
doc_path: "All New Website/Case Studies Layout.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308780/Case+Studies+Layout"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar |  | The navigation bar to navigate to other pages |  |
| Hero Section | Engaging hero section with a catchy tagline, high-quality background image, and a clear call-to-action button. | Title: Our Case Studies Subtitle: We collaborate with businesses to solve complex challenges through scalable, secure, and tailored solutions. These stories showcase the real impact of our work—and the long-term partnerships we’re proud to build. | Hero section.png |
| Our Case Studies | Real-world success stories and client case studies that demonstrate how PTN solutions have delivered measurable results. | Title: Case Studies Subtitle: We collaborate with businesses to solve complex challenges through scalable, secure, and tailored solutions. These stories showcase the real impact of our work—and the long-term partnerships we’re proud to build. Behavior: - Show 5 latest case studies → Each one will include a explore more to navigate to a detail page | Our Case Studies.png |
| Footer | Include company info, quick links, social media, and contact details. |  | We collaborate with businesses to solve complex challenges through scalable, secure, and tailored solutions. These stories showcase the real impact of our work—and the long-term partnerships we’re proud to build. |

## Full UI:

[Case Studies.png](https://ptnglobal.sharepoint.com/:i:/s/delivery/EQIzyO8maVhAs-6C33AA-a4Beygle8P0om1oic5I0GXzvQ?e=5bEuHP)

## Case Studies Detail

[Case Studies details.jpg](https://ptnglobal.sharepoint.com/:i:/s/delivery/EcQmjYmLe_tImfo2SrzgOxMBdRsWokNhchBq8-_zXlLRqg?e=IxF6ja)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the content |  |
