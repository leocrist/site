---
title: "Career Detail Layout"
confluence_page_id: "63308436"
confluence_space: "IN"
parent: "All New Website"
sort_order: 9
doc_path: "All New Website/Career Detail Layout.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308436/Career+Detail+Layout"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar | The navigation bar to navigate to other pages |  |  |
| Hero Section | Show the title of the job position | Title: {Job Title} | Hero section.png |
| Job Description | Show the job description | Content: Section 1: - Employment Type - Created Date - End Date - {Applied Now} button → Click to it to navigate to the Ready to apply form Additional Behavior: - Section 1 will remain sticky when scrolling down the content until users reach the application form, allowing them to click ‘Apply now’ at any time. Section 2: - About Us - What You’ll Do - What We’re Looking For - Nice to Have - Why Join Us - How to Apply:Content : If you're excited about building back-end systems that scale and love working in a high-impact role, we’d love to hear from you. Apply now or send your CV to [careers@yourcompany.com]. | Content.png |
| Ready to Apply | Show the ready to apply form | - Detail in the table below | Ready to apply.png |
| Footer | Include company info, quick links, social media, and contact details. |  | Hero section.png |

## Full UI:

[Career Details.jpg](https://ptnglobal.sharepoint.com/:i:/s/delivery/EdTQ4dTj8gNAu4TTtRZsTngBtlpZAobIo5VNksTVDF36MA?e=ZCewk0)

## Ready to Apply Form:

| No | Label | Type | Required | Validation | Error Message | Note |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | First Name | Text input | Yes | - Cannot be empty | - This field is required |  |
| 2 | Last name | Text input | Yes | - Cannot be empty | - This field is required |  |
| 3 | Email | Text input | Yes | - Cannot be empty | - This field is required |  |
| 4 | LinkedIn URL | Text input | No | - URL is linkedin URL | - Please provide the correct URL |  |
| 5 | Location | Text input | Yes | - Cannot be empty | - This field is required |  |
| 6 | Resume | File upload | Yes | - Cannot be empty - File is PDF | - This field is required - Only PDF file is accepted |  |
| 7 | Preferred Name | Text input | No |  |  |  |
| 8 | We expect all candidates to complete any technical (online or virtual interviews) independently, without the use of AI tools, collaboration with others, or copying solutions from external sources. We have measures in place to detect plagiarism and AI-assisted responses. If we find evidence of cheating, your application will be disqualified, and you will be removed from consideration for this role. We value honesty and integrity as core principles of our company culture, and we trust that you will approach this test in the same spirit. Do you acknowledge this statement and agree to not use AI to conduct your interviews unless otherwise noted by your interviewer? * | Radio button | Yes |  |  | Options: - Yes - No Default: - Yes |
| 9 | Gender | Dropdown list | Yes |  |  | Options: - Male - Female - Others Default: - Male |
| 10 | By applying you agree to PTN Global terms and privacy policy. Save your info to apply to other roles faster & help employers reach you. | Text label | # |  |  | - Users click to terms and privacy policy → Redirect them to the term and policy |
| 12 | Submit | Button | # |  |  | - Click this button to send the CV to the HR email |

## 

## Email UI:

[Email.png](https://ptnglobal.sharepoint.com/:i:/s/delivery/Ecvowd-r-GtGqqdAEnbdLAwBQ48kFunQiK6m-G8qDcqMiw?e=rwY8Hs)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the content |  |
