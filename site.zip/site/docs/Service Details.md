---
title: "Service Details"
confluence_page_id: "63308464"
confluence_space: "IN"
parent: "All New Website"
sort_order: 13
doc_path: "All New Website/Service Details.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308464/Service+Details"
provenance: confluence-export
---

## Service Detail Structure

| Section | Purpose | UI |
| --- | --- | --- |
| Navbar | Simple and intuitive navigation menu for seamless access across the website. |  |
| Hero Section | An engaging hero section with a catchy tagline, high-quality background image, and a clear call-to-action button. | Hero section.png |
| What We Offer | Overview of the key services provided, highlighting value and benefits to clients. | What we offer.png |
| Technology Stack | Showcase three main features or technologies offered, with concise descriptions and supporting icons. | Our engineering tech stack.png |
| Industries We Work In | Brief overview of the industries served, along with the company’s mission and vision. | Industry that we work on.png |
| Why Choose PTN | Reasons to partner with PTN, emphasizing strengths, expertise, and commitment to clients. | Why you should choose PTN.png |
| Our Process | Step-by-step explanation of how PTN approaches and delivers successful projects. | How we follow to complete your project.png |
| Case Studies | Examples of past projects with insights into challenges, solutions, and results achieved. | Our Case Studies.png |
| FAQ | Answers to frequently asked questions to help clients better understand services and processes. | Frequently Asked Questions (FAQs).png |
| Footer | Key company details, contact information, and quick access links. | Footer.png |

## Full UI:

[Service Details.png](https://ptnglobal.sharepoint.com/:i:/s/delivery/EcYi3vml8KJIpwaU0Cu7ivkBy5Yp9C5pmywcTDDNa9f63w?e=djs7vD)

## Service Detail Content Document

| # | Category | Service |
| --- | --- | --- |
| 1 | Core Application Development | Custom Software Development |
| 2 | Web Application Development |
| 3 | Mobile Application Development |
| 4 | Desktop Application Development |
| 5 | Enterprise Application Development |
| 6 | API Development & Integration |
| 7 | Product Engineering Services |
| 8 | Emerging Technologies | AI & Machine Learning Solutions |
| 9 | Data Science & Big Data Solutions |
| 10 | Generative AI Application Development |
| 11 | AI Agent & Autonomous Workflow Development |
| 12 | Cloud & DevOps | Cloud-Native Application Development |
| 13 | DevOps Consulting & Automation |
| 14 | Cloud Migration Services |
| 15 | Testing & Quality Assurance | Manual Testing |
| 16 | Automated Testing |
| 17 | Performance Testing |
| 18 | Security Testing |
| 19 | Design, Support & Maintenance | UI/UX Design & Prototyping |
| 20 | Application Maintenance & Support |
| 21 | Legacy System Modernization |
| 22 | System Integration Services |
