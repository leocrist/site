---
title: "Whitepaper Details"
confluence_page_id: "63308459"
confluence_space: "IN"
parent: "All New Website"
sort_order: 12
doc_path: "All New Website/Whitepaper Details.md"
source: "https://confluence.ptnglobalcorp.com/spaces/IN/pages/63308459/Whitepaper+Details"
provenance: confluence-export
---

## Expertise Layout

| Section | Purpose | Content in the section | UI |
| --- | --- | --- | --- |
| Navbar | Main navigation bar with links to key sections of the website. |  |  |
| Hero Section | Hero section with a catchy tagline, a high-quality background image, and a clear call-to-action button. | Title: {Title of the blog}Subtitle: - Created date: dd/mm/yyyy - Minute read | Hero section.png |
| Content | Overview of the different services or topics the company covers, presented with short descriptions. | - Show the content of the whitespaper - There is a table of content to show the content of the newspaper List of content - Written by - Categories | Content.png |
| Suggested Whitepapers | Show the suggested Whitepapers | Title: Suggested Whitepapers Behavior: - Show 3 latest blogs that related to that category | Suggested Whitepapers.png |
| Footer | Contains essential links, company information, contact details, and social media connections. |  | Footer.png |

## Full UI:

[Whitepapers Details.jpg](https://ptnglobal.sharepoint.com/:i:/s/delivery/Ed43cJvDJ91IoUHh9gmxVx4BlU3Naw5ix8mPUwL84YjL6A?e=b0Rbaa)

## Request:

| Requestion | Response |
| --- | --- |
| Please help me review the behavior and wireframe |  |
